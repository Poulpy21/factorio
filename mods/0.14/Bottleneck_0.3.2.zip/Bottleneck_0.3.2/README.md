# Bottleneck
Factorio mod that tell you which assemblers are starved of ingredients
