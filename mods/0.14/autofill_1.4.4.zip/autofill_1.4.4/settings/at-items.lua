--
-- Disclaimer: mp warranty void if edited.
--

--Advanced Tank Extend Arrays

return {
	--advanced Tanks
    ["ammo-shotgun"]	= {"piercing-shotgun-shell-brick"},
	["ammo-bullets"]		= {"ap-bullet-brick"},
	["ammo-shells"] 		= {"cannon-shell-2", "ap-cannon-shell", "hiex-cannon-shell"},

	--Tankwerkz
	--["ammo-shells"] = {"ap-cannon-shell", "hiex-cannon-shell"}

}
