--
-- Disclaimer: mp warranty void if edited.
--
--Advanced Tank New Item Arrays

return {
	--Advanced Tanks
	["gi-ammo-flame"] 	= {"flame-thrower-ammo-tanker"},
	["gi-ammo-mine"]  	= {"minepack", "minepack-poison"},
	["gi-ammo-artillery"] = {"50mm-mortar", "50mm-mortar-poison"},
	["gi-ammo-wmd"]  	= {"tank-wmd-ammo"},
	["gi-ammo-rocket"]	= {"rocketpack"},
	["gi-ammo-auto45"]	=	{"45mm-auto"},

	--Tankwerkz
	["tw-ammo-rocket"]	= {"hydra-rocket"},
	["tw-ammo-belt"] = {"heavy-mg-ammo"},
	["tw-ammo-flame"] = {"tank-flame-thrower-ammo"},

}
