--
-- Disclaimer: mp warranty void if edited.
--



return {
  ["ammo-bullets"] = {"electric-bullet-magazine", "poison-bullet-magazine", "acid-bullet-magazine", "flame-bullet-magazine", "he-bullet-magazine", "ap-bullet-magazine", "bullet-magazine"},
  ["ammo-shells"] = {"scatter-cannon-shell"}
}
